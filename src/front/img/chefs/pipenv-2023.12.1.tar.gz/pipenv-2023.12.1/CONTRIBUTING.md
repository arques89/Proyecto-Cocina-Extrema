Contributing to Pipenv
======================

Please see: [docs/dev/contributing.rst](https://pipenv.pypa.io/en/latest/dev/contributing/).
