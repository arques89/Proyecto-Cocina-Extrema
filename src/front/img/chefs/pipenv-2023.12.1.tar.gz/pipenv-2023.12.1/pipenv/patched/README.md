# Don't touch!

- Pip is modified, to make it work with Pipenv's custom virtualenv locations.
- Pip is modified, to make it work with pip-tool modifications.
- Pip is modified, to make it resolve deep extras links.
- Safety is hacked together to always work on any system.
- TOML libraries are upgraded to... work.

Don't touch.

When updating (remember, don't touch!), update the corresponding LICENSE files as well.
